package com.ssm.dao;

import org.springframework.stereotype.Repository;

import com.ssm.model.User;
/**
 * 
 * @author Michael
 * @Date 2015-05-08
 *
 */
@Repository
public interface UserDao {

	public int insertUser(User user);

}
