package com.ssm.service;

import com.ssm.model.User;
/**
 * 
 * @author Michael
 * @Date 2015-05-08
 *
 */
public interface UserService {
    public int insertUser(User user);

}
