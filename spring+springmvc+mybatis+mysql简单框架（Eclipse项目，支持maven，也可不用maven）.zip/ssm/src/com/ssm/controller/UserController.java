package com.ssm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.model.User;
import com.ssm.service.UserService;
/**
 * 
 * @author Michael
 * @Date 2015-05-08
 *
 */
@Controller
@RequestMapping("/")
public class UserController {
	@Autowired
	private UserService userService;

	/**
	 * 进入登录页面
	 *
	 * @return
	 */
	@RequestMapping("/")
	public String index() {
		return "index";
	}

	/**
	 * 添加操作
	 *
	 * @param users
	 * @return
	 */
	@RequestMapping("user/add")
	@ResponseBody
	public boolean add(User user) {
		boolean flag;
		try {
			userService.insertUser(user);
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		}
		return flag;
	}
}
