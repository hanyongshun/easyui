/*
Navicat MySQL Data Transfer

Source Server         : php
Source Server Version : 50520
Source Host           : localhost:3306
Source Database       : mydb

Target Server Type    : MYSQL
Target Server Version : 50520
File Encoding         : 65001

Date: 2014-10-10 16:22:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for baoshi
-- ----------------------------
DROP TABLE IF EXISTS `baoshi`;
CREATE TABLE `baoshi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `createTime` date DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `userKey` varchar(255) DEFAULT NULL,
  `processInstanceId` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of baoshi
-- ----------------------------
INSERT INTO `baoshi` VALUES ('79', 'baoshi', '2014-09-16', '23', 'admin', '3100a19d-4227-11e4-b397-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('80', 'baoxiu', '2014-09-29', '23', 'admin', 'f2ff173e-422e-11e4-b397-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('81', 'baoshi', '2014-09-25', '45', 'admin', '25f60ef7-4235-11e4-a393-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('82', 'baoshi', '2014-09-23', '111', 'zw', 'edb96c27-42c5-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('83', 'baoshi', '2014-09-23', '23', 'zw', '77af26e1-42c7-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('84', 'baoshi', '2014-09-23', 'test', 'zw', 'c20ca0b5-42c7-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('85', 'baoshi', '2014-09-23', '23', 'zw', '85f2c643-42c8-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('86', 'baoshi', '2014-09-23', '23', 'szc', '201647aa-42cc-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('87', 'baoxiu', '2014-09-23', '测试1', 'szc', '685a0936-42cc-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('88', 'baoshi', '2014-09-23', '测试2', 'szc', '7b6f7152-42cc-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('89', 'baoshi', '2014-09-23', '测试3', 'szc', '8b64fbce-42cc-11e4-99fd-f8bc1268aae5');
INSERT INTO `baoshi` VALUES ('90', 'baoshi', '2014-09-23', '测试4', 'admin', '4476268a-42cd-11e4-99fd-f8bc1268aae5');

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TEXT` varchar(255) DEFAULT NULL,
  `PID` int(11) DEFAULT NULL,
  `URL` varchar(255) DEFAULT NULL,
  `SEQ` varchar(255) DEFAULT NULL,
  `ICONCLS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES ('1', '首页', null, '', '', '');
INSERT INTO `menu` VALUES ('2', '系统管理', '1', null, null, '');
INSERT INTO `menu` VALUES ('3', '流程管理', '1', null, null, '');
INSERT INTO `menu` VALUES ('4', '菜单管理', '2', null, null, '');
INSERT INTO `menu` VALUES ('5', '用户管理', '2', '/SpringMVC-EasyUI-Activiti-Maven/user/listPage', null, '');
INSERT INTO `menu` VALUES ('6', '角色管理', '2', null, null, '');
INSERT INTO `menu` VALUES ('7', '模型工作区', '3', '/SpringMVC-EasyUI-Activiti-Maven/workflow/model/list', null, '');
INSERT INTO `menu` VALUES ('8', '流程定义', '3', '/SpringMVC-EasyUI-Activiti-Maven/workflow/process/list', null, '');
INSERT INTO `menu` VALUES ('9', '业务流程管理', '1', null, null, '');
INSERT INTO `menu` VALUES ('10', '报事流程', '9', '/SpringMVC-EasyUI-Activiti-Maven/baoshi/main', null, '');
INSERT INTO `menu` VALUES ('12', '待办工单', '10', '/SpringMVC-EasyUI-Activiti-Maven/undoTaskList', null, '');
INSERT INTO `menu` VALUES ('14', '我的完成工单', '16', '/SpringMVC-EasyUI-Activiti-Maven/history-owner-task', null, '');
INSERT INTO `menu` VALUES ('15', '我的处理工单', '16', '/SpringMVC-EasyUI-Activiti-Maven/baoshi/history-involved-page', null, '');
INSERT INTO `menu` VALUES ('16', '历史工单', '10', null, null, '');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `userId` varchar(100) DEFAULT NULL,
  `email` varchar(400) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('12', '1222', '221', '21', '12', '12', '2014-08-18', '12', '12122');
INSERT INTO `user` VALUES ('13', '23', '23', '23', '23', '23', '2014-08-21', '23', '23');
INSERT INTO `user` VALUES ('14', '12', '2', '12', '12', '21', '2014-08-29', '12', '12');
INSERT INTO `user` VALUES ('15', '2323', '2343', '34', '34', '34', '2014-08-19', '34', '34');
INSERT INTO `user` VALUES ('20', 'admin', '23', '23', 'admin', '2323', '2014-08-28', '2', '23');
INSERT INTO `user` VALUES ('21', 'kafeitu', '23', '23', '000000', '23', '2014-08-28', '2', '23');
INSERT INTO `user` VALUES ('22', 'leaderuser', '23', '24', '000000', '23', '2014-08-28', '23', '23');
INSERT INTO `user` VALUES ('23', 'hruser', '213', '23', '000000', '3', '2014-08-28', '23', '23');
INSERT INTO `user` VALUES ('29', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('30', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('35', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('36', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('37', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('38', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('39', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('40', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('41', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('42', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('43', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('44', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('45', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('46', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('47', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('48', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('49', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('50', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('51', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('52', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('53', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('54', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('55', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('56', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('57', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('58', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('59', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('60', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('61', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('62', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('63', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('64', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('65', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('66', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('67', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('68', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('69', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('70', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('71', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('72', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('73', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('74', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('75', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('76', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('77', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('78', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('79', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('80', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('81', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('82', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('83', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('84', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('85', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('86', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('87', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('88', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('89', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('90', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('91', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('92', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('93', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('94', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('95', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('96', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('97', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('98', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('99', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('100', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('101', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('102', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('103', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('104', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('105', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('106', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('107', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('108', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('109', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('110', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('111', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('112', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('113', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('114', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('115', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('116', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('117', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('119', '34', '34', '34', '34', '34', '2014-09-30', '34', '34');
INSERT INTO `user` VALUES ('229', '23', '23@4323.com', '0', '23', '23', '2014-09-30', '23', '23');
INSERT INTO `user` VALUES ('230', '23', '23@2335353.com', '0', '23', '23', '2014-09-09', '23', '23');
INSERT INTO `user` VALUES ('231', 'szc', 'shi_zhenchao@126.com', '0', 'szc', '内蒙古通辽市科尔沁区', '2014-08-21', '610275125', '25');
INSERT INTO `user` VALUES ('232', 'ss', 'ss@qq.com', '0', 'ss', 'ss', '2014-09-23', 'ss', 'ss');
INSERT INTO `user` VALUES ('235', 'gyj', 'gyj@qq.com', '0', 'gyj', 'gyj', '2014-09-23', 'gyj', 'gyj');
INSERT INTO `user` VALUES ('236', 'lb', 'lb@qq.com', '0', 'lb', 'lb', '2014-09-23', 'lb', 'lb');
INSERT INTO `user` VALUES ('238', 'zw', 'zw@qq.com', '0', 'zw', 'zw', '2014-09-23', 'zw', 'zw');



--activiti
insert into ACT_ID_GROUP values ('admin', 1, '管理员', 'security-role');
insert into ACT_ID_GROUP values ('user', 1, '用户', 'security-role');
insert into ACT_ID_GROUP values ('deptLeader', 1, '部门领导', 'assignment');
insert into ACT_ID_GROUP values ('hr', 1, '人事', 'assignment');

insert into ACT_ID_USER values ('admin', 1, 'Admin', 'Kad', 'admin@kad.com', '000000', '');
insert into ACT_ID_MEMBERSHIP values ('admin', 'user');
insert into ACT_ID_MEMBERSHIP values ('admin', 'admin');

insert into ACT_ID_USER values ('kafeitu', 1, 'Henry', 'Yan', 'yanhonglei@gmail.com', '000000', '');
insert into ACT_ID_MEMBERSHIP values ('kafeitu', 'admin');

insert into ACT_ID_USER values ('hruser', 1, 'Lili', 'Zhang', 'hr@gmail.com', '000000', '');
insert into ACT_ID_MEMBERSHIP values ('hruser', 'user');
insert into ACT_ID_MEMBERSHIP values ('hruser', 'hr');

insert into ACT_ID_USER values ('leaderuser', 1, 'Jhon', 'Li', 'leader@gmail.com', '000000', '');
insert into ACT_ID_MEMBERSHIP values ('leaderuser', 'user');
insert into ACT_ID_MEMBERSHIP values ('leaderuser', 'deptLeader');

update ACT_GE_PROPERTY
set VALUE_ = '10'
where NAME_ = 'next.dbid';