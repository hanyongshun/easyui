package com.ssm.activiti.web.service;

import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.identity.User;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;

import javax.servlet.http.HttpSession;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public interface WorkflowService {
    /**
     * 查询待办任务
     *
     * @param session
     * @param pageNo
     * @param pageSize @return
     */
    public List<Task> showUndoTaskList(HttpSession session, int pageNo, int pageSize);

    /**
     * 查询待办记录总数
     */
    public long countUndoTaskList(HttpSession session);

    /**
     * 通过processInstanceId启动流程
     *
     * @param processInstanceId
     * @param businessKey
     * @param variables
     * @return
     */
    public ProcessInstance startProcessByProcessInstanceById(String applyUserId, String processInstanceId,
                                                             String businessKey, Map<String, Object> variables);

    /**
     * 通过流程key启动流程
     *
     * @param applyUserId
     * @param processInstanceKey
     * @param businessKey
     * @param variables
     * @return
     */
    public ProcessInstance startByKey(String applyUserId, String processInstanceKey,
                                      String businessKey, Map<String, Object> variables);

    /**
     * 完成当前节点
     *
     * @param taskId    工单id
     * @param variables 参数
     */
    public void referTask(String taskId, Map<String, Object> variables);

    /**
     * 完成当前节点的同时获得下一节点Id
     *
     * @param taskId
     * @param executionId
     * @param variables
     */
    public String referTask(String taskId, String executionId, Map<String, Object> variables);

    /**
     * 查询流程定义列表
     *
     * @return
     */
    public List<ProcessDefinition> definitionList(int firstResult,
                                                  int maxResults);

    /**
     * 查询流程信息
     *
     * @param pageNo
     * @param pageSize
     * @return
     */
    public List<Object[]> workflowInfo(int pageNo, int pageSize);

    /**
     * 读取xml、png等资源
     *
     * @param processDefinitionId
     * @param resourceType
     * @return
     */
    public InputStream readResource(String processDefinitionId, String resourceType);

    /**
     * 流程定义状态修改，激活、挂起
     *
     * @param state
     * @param processDefinitionId
     */
    public void updateState(String state, String processDefinitionId);

    /**
     * 签收工单
     *
     * @param taskId 工单ID
     * @param userId 用户ID
     */
    public void claim(String taskId, String userId);

    /**
     * 删除流程定义
     *
     * @param deploymentId
     */
    public void deleteDeployment(String deploymentId);

    /**
     * 根据当前登录人查询该人配发的已完成工单
     *
     * @param userId 用户id
     * @return
     */

    List<HistoricProcessInstance> finishedHistoricProcessInstances(
            String userId);

    /**
     * 根据实例id查找流转信息
     *
     * @param processInstanceId
     * @return
     */
    List<HistoricActivityInstance> historicActivityInstances(String processInstanceId);

    /**
     * 当前任务角色列表
     *
     * @param taskId
     * @return
     */
    List<String> currentTaskGroupIds(String taskId);

    /**
     * 根据groupId查询所有用户
     *
     * @param groupId
     * @return
     */
    List<User> searchUserIds(String groupId);

    ProcessInstance searchProcessInstanceById(String processInstanceId);

    /**
     * 通过taskId查询task
     *
     * @param taskId
     * @return
     */
    Task searchTaskByTaskId(String taskId);

    /**
     * 历史task实例
     *
     * @param taskId
     * @return
     */
    public HistoricTaskInstance searchHistoryTaskByTaskId(String taskId);

    /**
     * 历史处理工单
     *
     * @param userId
     * @param startNo
     * @param rows
     * @return
     */
    Map<String, Object> historyInvolvedUser(String userId, int startNo, int rows);

    HistoricProcessInstance searchHistoryProcessInstanceById(String processInstanceId);
}
