package com.ssm.activiti.web.service.impl;

import com.ssm.activiti.web.service.WorkflowProcessDefinitionService;
import com.ssm.web.model.PageHelper;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.repository.ProcessDefinitionQuery;
import org.activiti.engine.runtime.ProcessInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-25.
 */
@Service
public class WorkflowProcessDefinitionServiceImpl implements WorkflowProcessDefinitionService {
    protected Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    protected RuntimeService runtimeService;

    @Autowired
    protected RepositoryService repositoryService;

    @Autowired
    protected HistoryService historyService;

    /**
     * 根据流程实例Id查询流程定义Id
     *
     * @param processInstanceId
     * @return
     */
    @Override
    public ProcessDefinition findProcessDefinitionByPiid(String processInstanceId) {
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        String processDefinitionId = historicProcessInstance.getProcessDefinitionId();
        ProcessDefinition processDefinition = findProcessDefinitionByPdid(processDefinitionId);
        return processDefinition;
    }

    /**
     * 根据流程定义Id查询流程定义Id
     *
     * @param processDefinitionId
     * @return
     */
    @Override
    public ProcessDefinition findProcessDefinitionByPdid(String processDefinitionId) {
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
        return processDefinition;
    }

    /**
     * 流程定义列表
     *
     * @param pageHelper
     * @return
     */
    @Override
    public Map<String, Object> findProcessDefinitionList(PageHelper pageHelper) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        int pageSize = pageHelper.getRows();
        int pageNo = pageHelper.getPage() == 0 ? 1 : pageHelper.getPage();
        int startNo = (pageNo - 1) * pageSize;
         /*
         * 保存两个对象，一个是ProcessDefinition（流程定义），一个是Deployment（流程部署）
         */
        List<Map<String,Object>> objects = new ArrayList<Map<String,Object>>();
        Map<String,Object> mapforreturn = new HashMap<String, Object>();
        ProcessDefinitionQuery processDefinitionQuery = repositoryService.createProcessDefinitionQuery().orderByDeploymentId().desc();
        List<ProcessDefinition> processDefinitionList = processDefinitionQuery.listPage(startNo, pageHelper.getRows());
        int total = 0;
        if (processDefinitionList != null && processDefinitionList.size() > 0){
            total = processDefinitionList.size();
            for (ProcessDefinition processDefinition : processDefinitionList) {
                Map<String,Object> map = new HashMap<String, Object>();
                String deploymentId = processDefinition.getDeploymentId();
                Deployment deployment = repositoryService.createDeploymentQuery().deploymentId(deploymentId).singleResult();
                map.put("definitionId", processDefinition.getId());
                map.put("deployId", deployment.getId());
                map.put("definitionName", processDefinition.getName());
                map.put("definitionKey", processDefinition.getKey());
                map.put("definitionVersion", processDefinition.getVersion());
                map.put("definitionDiagramResourceName", processDefinition.getDiagramResourceName());
                map.put("definitionResourceName", processDefinition.getResourceName());
                map.put("deployTime", sdf.format(deployment.getDeploymentTime()));
                map.put("definitionSuspended",processDefinition.isSuspended());
                objects.add(map);
            }
        }
        mapforreturn.put("total",total);
        mapforreturn.put("rows",objects);
        return mapforreturn;
    }
    @Override
    public ProcessInstance startByKey(String applyUserId, String processInstanceKey, String businessKey, Map<String, Object> variables) {
        return null;
    }
}
