package com.ssm.activiti.web.service;

import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-25.
 */
public interface WorkflowTraceService {
    public List<Map<String, Object>> traceProcess(String processInstanceId) throws Exception ;
}
