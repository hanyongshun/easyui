package com.ssm.activiti.web.service.impl;

import com.ssm.activiti.web.service.WorkflowService;
import org.activiti.engine.*;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.identity.User;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.bpmn.behavior.UserTaskActivityBehavior;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.PvmActivity;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.task.TaskDefinition;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;
import org.activiti.engine.task.TaskQuery;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class WorkflowServiceImpl implements WorkflowService {

    Logger logger = LoggerFactory.getLogger(WorkflowServiceImpl.class);
    @Autowired
    public RepositoryService repositoryService;
    @Autowired
    public IdentityService identityService;
    @Autowired
    public RuntimeService runtimeService;
    @Autowired
    public TaskService taskService;
    @Autowired
    public HistoryService historyService;
    /**
     * Task相关查询
     */
    //------------------------------------------------------------------------------------------------------------------
    //------------------------------------------------------------------------------------------------------------------

    /**
     * 查询任务列表
     */
    @Override
    @Transactional(readOnly = true)
    public List<Task> showUndoTaskList(HttpSession session, int startNo, int pageSize) {
        String userId = (String) session.getAttribute("userId");
        return taskService.createTaskQuery().taskCandidateOrAssigned(userId).listPage(startNo, pageSize);//根据候选人或者处理人查询
    }

    /**
     * 查询待办记录总数
     *
     * @param session
     */
    @Override
    public long countUndoTaskList(HttpSession session) {
        String userId = (String) session.getAttribute("userId");
        return taskService.createTaskQuery().taskCandidateOrAssigned(userId).count();
    }

    /**
     * 签收工单
     */
    @Override
    public void claim(String taskId, String userId) {
        identityService.setAuthenticatedUserId(userId);
        taskService.claim(taskId, userId);
    }

    /**
     * 执行task
     */
    @Override
    public void referTask(String taskId, Map<String, Object> varables) {
        taskService.complete(taskId, varables);
    }

    /**
     * 完成当前节点的同时获得下一节点Id
     *
     * @param taskId
     * @param executionId
     * @param variables
     */
    @Override
    public String referTask(String taskId, String executionId, Map<String, Object> variables) {
        TaskQuery taskQuery = taskService.createTaskQuery();
        //完成当前节点
        taskService.complete(taskId, variables);
        //获取下一环节任务id
        Task nextTask = taskQuery.executionId(executionId).singleResult();
        String nextTaskId = nextTask.getId();
        return nextTaskId;
    }

    /**
     * 通过taskId查询task
     *
     * @param taskId
     * @return
     */
    @Override
    public Task searchTaskByTaskId(String taskId) {
        Task task = null;
        try {
            task = taskService.createTaskQuery().taskId(taskId).singleResult();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return task;
    }

    /**
     * 历史task实例
     *
     * @param taskId
     * @return
     */
    public HistoricTaskInstance searchHistoryTaskByTaskId(String taskId) {
        HistoricTaskInstance historicTaskInstance = historyService.createHistoricTaskInstanceQuery().taskId(taskId).singleResult();
        return historicTaskInstance;
    }

    /**
     * 查询我参与处理的工单
     *
     * @param userId
     * @param startNo
     * @param rows
     * @return
     */
    public Map<String, Object> historyInvolvedUser(String userId, int startNo, int rows) {
        List<HistoricProcessInstance> historicProcessInstances = historyService.createHistoricProcessInstanceQuery().involvedUser(userId).listPage(startNo, rows);
        long total = historyService.createHistoricProcessInstanceQuery().involvedUser(userId).count();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("rows", historicProcessInstances);
        map.put("total", total);
        return map;
    }

    /**
     * 根据流程实例ID查询历史流程实例
     *
     * @param processInstanceId
     * @return
     */
    public HistoricProcessInstance searchHistoryProcessInstanceById(String processInstanceId) {
        return historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
    }


    /**
     * 流程实例相关操作
     */
    //------------------------------------------------------------------------------------------------------------------
    //------------------------------------------------------------------------------------------------------------------

    /**
     * 启动流程，通过id
     */
    @Override
    public ProcessInstance startProcessByProcessInstanceById(
            String applyUserId, String processInstanceId, String businessKey,
            Map<String, Object> variables) {
        ProcessInstance processInstance = null;
        try {
            identityService.setAuthenticatedUserId(applyUserId);
            processInstance = runtimeService.startProcessInstanceById(
                    processInstanceId, businessKey, variables);
            Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
            List<String> list = currentTaskGroupIds(task.getId());
            logger.debug("角色组" + list);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            identityService.setAuthenticatedUserId(null);
        }
        return processInstance;
    }

    /**
     * 通过key启动流程实例
     */
    @Override
    public ProcessInstance startByKey(
            String applyUserId, String processInstanceKey, String businessKey,
            Map<String, Object> variables) {
        ProcessInstance processInstance = null;
        try {
            identityService.setAuthenticatedUserId(applyUserId);
            processInstance = runtimeService.startProcessInstanceByKey(
                    processInstanceKey, businessKey, variables);
            Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
            List<String> list = currentTaskGroupIds(task.getId());
            logger.debug("角色组" + list);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            identityService.setAuthenticatedUserId(null);
        }
        return processInstance;
    }

    /**
     * 通过流程实例Id查询流程实例
     *
     * @param processInstanceId
     * @return
     */
    @Override
    public ProcessInstance searchProcessInstanceById(String processInstanceId) {
        return runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).active().singleResult();
    }


    /**
     * 流程定义相关操作
     */
    //------------------------------------------------------------------------------------------------------------------
    //------------------------------------------------------------------------------------------------------------------

    /**
     * 查询流程定义列表
     */
    @Override
    public List<ProcessDefinition> definitionList(int firstResult,
                                                  int maxResults) {
        List<ProcessDefinition> definitions = null;
        try {
            definitions = repositoryService.createProcessDefinitionQuery()
                    .orderByDeploymentId().desc()
                    .listPage(firstResult, maxResults);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return definitions;
    }

    /**
     * 查询流程综合信息，流程定义表和流程发布表
     */
    @Override
    public List<Object[]> workflowInfo(int pageNo, int pageSize) {
        List<Object[]> obj = new ArrayList<Object[]>();
        List<ProcessDefinition> definitions = this.definitionList(pageNo,
                pageSize);
        if (definitions != null && definitions.size() > 0) {
            for (ProcessDefinition definition : definitions) {
                Deployment deployment = repositoryService
                        .createDeploymentQuery()
                        .deploymentId(definition.getDeploymentId())
                        .singleResult();
                obj.add(new Object[]{definition, deployment});
            }
        }
        return obj;
    }

    /**
     * 读取xml,图片等资源
     *
     * @param processDefinitionId
     * @param resourceType
     * @return
     */
    @Override
    public InputStream readResource(String processDefinitionId,
                                    String resourceType) {
        ProcessDefinition processDefinition = repositoryService
                .createProcessDefinitionQuery()
                .processDefinitionId(processDefinitionId).singleResult();
        String resourceName = "";
        if (resourceType.equals("image")) {
            resourceName = processDefinition.getDiagramResourceName();
        } else if (resourceType.equals("xml")) {
            resourceName = processDefinition.getResourceName();
        }
        InputStream resourceAsStream = repositoryService.getResourceAsStream(
                processDefinition.getDeploymentId(), resourceName);
        return resourceAsStream;
    }

    /**
     * 更改流程定义状态，挂起还是激活
     */
    @Override
    public void updateState(String state, String processDefinitionId) {
        if (state.equals("active")) {
            repositoryService.activateProcessDefinitionById(
                    processDefinitionId, true, null);
        } else if (state.equals("suspend")) {
            repositoryService.suspendProcessDefinitionById(
                    processDefinitionId, true, null);
        }
    }

    /**
     * 根据实例编号查找下一个任务节点
     *
     * @param procInstId
     * @return
     */
    public TaskDefinition nextTaskDefinition(String procInstId) {
        //流程标示
        String processDefinitionId = historyService.createHistoricProcessInstanceQuery().processInstanceId(procInstId).singleResult().getProcessDefinitionId();

        ProcessDefinitionEntity def = (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(processDefinitionId);
        //执行实例
        ExecutionEntity execution = (ExecutionEntity) runtimeService.createProcessInstanceQuery().processInstanceId(procInstId).singleResult();
        //当前实例的执行到哪个节点
        String activitiId = execution.getActivityId();
        //获得当前任务的所有节点
        List<ActivityImpl> activitiList = def.getActivities();
        String id = null;
        for (ActivityImpl activityImpl : activitiList) {
            id = activityImpl.getId();
            if (activitiId.equals(id)) {
                System.out.println("当前任务：" + activityImpl.getProperty("name"));
                return nextTaskDefinition(activityImpl, activityImpl.getId(), "${iscorrect==1}");
            }
        }
        return null;
    }

    /**
     * 下一个任务节点
     *
     * @param activityImpl
     * @param activityId
     * @param elString
     * @return
     */
    private TaskDefinition nextTaskDefinition(ActivityImpl activityImpl, String activityId, String elString) {
        if ("userTask".equals(activityImpl.getProperty("type")) && !activityId.equals(activityImpl.getId())) {
            TaskDefinition taskDefinition = ((UserTaskActivityBehavior) activityImpl.getActivityBehavior()).getTaskDefinition();
            return taskDefinition;
        } else {
            List<PvmTransition> outTransitions = activityImpl.getOutgoingTransitions();
            List<PvmTransition> outTransitionsTemp = null;
            for (PvmTransition tr : outTransitions) {
                PvmActivity ac = tr.getDestination(); //获取线路的终点节点
                if ("exclusiveGateway".equals(ac.getProperty("type"))) {
                    outTransitionsTemp = ac.getOutgoingTransitions();
                    if (outTransitionsTemp.size() == 1) {
                        return nextTaskDefinition((ActivityImpl) outTransitionsTemp.get(0).getDestination(), activityId, elString);
                    } else if (outTransitionsTemp.size() > 1) {
                        for (PvmTransition tr1 : outTransitionsTemp) {
                            Object s = tr1.getProperty("conditionText");
                            if (elString.equals(StringUtils.trim(s.toString()))) {
                                return nextTaskDefinition((ActivityImpl) tr1.getDestination(), activityId, elString);
                            }
                        }
                    }
                } else if ("userTask".equals(ac.getProperty("type"))) {
                    return ((UserTaskActivityBehavior) ((ActivityImpl) ac).getActivityBehavior()).getTaskDefinition();
                } else {
                    logger.debug((String) ac.getProperty("type"));
                }
            }
            return null;
        }
    }


    /**
     * 删除流程定义
     */
    @Override
    public void deleteDeployment(String deploymentId) {
        repositoryService.deleteDeployment(deploymentId);
    }

    /**
     * 根据当前用户登录id查询已经完成的流程实例
     *
     * @param userId
     * @return
     */
    @Override
    public List<HistoricProcessInstance> finishedHistoricProcessInstances(
            String userId) {
        List<HistoricProcessInstance> historicProcessInstances = historyService.createHistoricProcessInstanceQuery().finished().startedBy(userId).orderByProcessInstanceStartTime().desc().list();
        return historicProcessInstances;
    }

    /**
     * 通过实例id查找历史表中的流转信息
     */
    @Override
    public List<HistoricActivityInstance> historicActivityInstances(String processInstanceId) {
        List<HistoricActivityInstance> historicActivityInstances = historyService.createHistoricActivityInstanceQuery().processInstanceId(processInstanceId).finished().orderByHistoricActivityInstanceStartTime().asc().list();
        return historicActivityInstances;
    }


    /**
     * 当前任务角色列表
     *
     * @param taskId
     * @return
     */
    @Override
    public List<String> currentTaskGroupIds(String taskId) {
        //一个任务可能有多个角色处理
        List<IdentityLink> identityLinks = taskService.getIdentityLinksForTask(taskId);
        List<String> roles = new ArrayList<String>();
        for (IdentityLink identityLink : identityLinks) {
            roles.add(identityLink.getGroupId());
        }
        return roles;
    }

    /**
     * 根据groupId查询所有用户
     *
     * @param groupId
     * @return
     */
    @Override
    public List<User> searchUserIds(String groupId) {
        List<User> list = identityService.createUserQuery().memberOfGroup(groupId).list();
        return list;
    }

}
