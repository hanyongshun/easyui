package com.ssm.activiti.web.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ssm.activiti.utils.WorkflowUtils;
import com.ssm.activiti.web.service.WorkflowProcessDefinitionService;
import com.ssm.activiti.web.service.WorkflowTraceService;
import com.ssm.web.model.PageHelper;
import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ProcessDefinition;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipInputStream;

/**
 * Created by shizhenchao on 2014-8-25.
 */
@Controller
@RequestMapping("/workflow/process")
public class ActivitiController {
    protected Logger logger = LoggerFactory.getLogger(ActivitiController.class);
    @Autowired
    protected WorkflowProcessDefinitionService workflowProcessDefinitionService;
    @Autowired
    protected RepositoryService repositoryService;
    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    protected TaskService taskService;
    @Autowired
    protected WorkflowTraceService workflowTraceService;
    @Autowired
    protected HistoryService historyService;

    /**
     * 加载流程&部署列表
     *
     * @return
     */
    @RequestMapping("list")
    public String processlist() {
        return "process/processlist";
    }

    @RequestMapping(value = "jsonList", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public Map<String, Object> list(PageHelper pageHelper) {
        Map<String, Object> map = null;
        try {
            map = new HashMap<String, Object>();
            map = workflowProcessDefinitionService.findProcessDefinitionList(pageHelper);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("获取列表出错：列表信息={}", map, e);
        }
        return map;
    }

    /**
     * 流程发布
     *
     * @param exportDir
     * @param file
     * @return
     */
    @RequestMapping(value = "/deploy")
    @ResponseBody
    public boolean deploy(@Value("#{APP_PROPERTIES['export.diagram.path']}") String exportDir, @RequestParam(value = "file", required = false) MultipartFile file) {

        String fileName = file.getOriginalFilename();
        boolean flag;
        try {
            InputStream fileInputStream = file.getInputStream();
            Deployment deployment = null;

            String extension = FilenameUtils.getExtension(fileName);
            if (extension.equals("zip") || extension.equals("bar")) {
                ZipInputStream zip = new ZipInputStream(fileInputStream);
                deployment = repositoryService.createDeployment().addZipInputStream(zip).deploy();
            } else {
                deployment = repositoryService.createDeployment().addInputStream(fileName, fileInputStream).deploy();
            }

            List<ProcessDefinition> list = repositoryService.createProcessDefinitionQuery().deploymentId(deployment.getId()).list();

            for (ProcessDefinition processDefinition : list) {
                WorkflowUtils.exportDiagramToFile(repositoryService, processDefinition, exportDir);
            }

        } catch (Exception e) {
            logger.error("流程发布失败", e);
            flag = false;
            return flag;
        }
        flag = true;
        return flag;
    }

    /**
     * 删除流程定义
     *
     * @param ids
     */
    @RequestMapping("delete")
    @ResponseBody
    public boolean delete(@RequestParam String ids) {
        boolean flag;
        try {
            String[] ids_arr = ids.split(",");
            for (int i = 0; i < ids_arr.length; i++) {
                String modelId = ids_arr[i];
                repositoryService.deleteDeployment(modelId);
            }
        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
            return flag;
        }
        flag = true;
        return flag;
    }

    @RequestMapping(value = "convert-to-model")
    @ResponseBody
    public boolean convertToModel(@RequestParam String pdids)
            throws UnsupportedEncodingException, XMLStreamException {
        //切割pdids
        boolean flag;
        try {
            String[] pdidsArray = pdids.split(",");
            if (pdidsArray.length > 0) {
                for (String pdid : pdidsArray) {
                    ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                            .processDefinitionId(pdid).singleResult();
                    InputStream bpmnStream = repositoryService.getResourceAsStream(processDefinition.getDeploymentId(),
                            processDefinition.getResourceName());
                    XMLInputFactory xif = XMLInputFactory.newInstance();
                    InputStreamReader in = new InputStreamReader(bpmnStream, "UTF-8");
                    XMLStreamReader xtr = xif.createXMLStreamReader(in);
                    BpmnModel bpmnModel = new BpmnXMLConverter().convertToBpmnModel(xtr);

                    BpmnJsonConverter converter = new BpmnJsonConverter();
                    ObjectNode modelNode = converter.convertToJson(bpmnModel);
                    Model modelData = repositoryService.newModel();
                    modelData.setKey(processDefinition.getKey());
                    modelData.setName(processDefinition.getResourceName());
                    modelData.setCategory(processDefinition.getDeploymentId());

                    ObjectNode modelObjectNode = new ObjectMapper().createObjectNode();
                    modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, processDefinition.getName());
                    modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
                    modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, processDefinition.getDescription());
                    modelData.setMetaInfo(modelObjectNode.toString());

                    repositoryService.saveModel(modelData);

                    repositoryService.addModelEditorSource(modelData.getId(), modelNode.toString().getBytes("utf-8"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
            return flag;
        }
        flag = true;
        return flag;
    }
}
