package com.ssm.activiti.web.model;

import java.io.Serializable;

/**
 * Created by shizhenchao on 2014-8-26.
 */
public class ProcessDefinitionAndDeployment implements Serializable {
    private String processDefinitionId;//流程定义Id
    private String processDefinitionName;
    private String processDefinitionKey;
    private Integer processDefinitionVersion;
    private String processDefinitionXML;
    private String processDefinitionPic;
    private Boolean processDefinitionActive;
    private String processDeployTime;
    private String processDeployId;

    public String getProcessDefinitionId() {
        return processDefinitionId;
    }

    public void setProcessDefinitionId(String processDefinitionId) {
        this.processDefinitionId = processDefinitionId;
    }

    public String getProcessDefinitionName() {
        return processDefinitionName;
    }

    public void setProcessDefinitionName(String processDefinitionName) {
        this.processDefinitionName = processDefinitionName;
    }

    public String getProcessDefinitionKey() {
        return processDefinitionKey;
    }

    public void setProcessDefinitionKey(String processDefinitionKey) {
        this.processDefinitionKey = processDefinitionKey;
    }

    public Integer getProcessDefinitionVersion() {
        return processDefinitionVersion;
    }

    public void setProcessDefinitionVersion(Integer processDefinitionVersion) {
        this.processDefinitionVersion = processDefinitionVersion;
    }

    public String getProcessDefinitionXML() {
        return processDefinitionXML;
    }

    public void setProcessDefinitionXML(String processDefinitionXML) {
        this.processDefinitionXML = processDefinitionXML;
    }

    public String getProcessDefinitionPic() {
        return processDefinitionPic;
    }

    public void setProcessDefinitionPic(String processDefinitionPic) {
        this.processDefinitionPic = processDefinitionPic;
    }

    public Boolean getProcessDefinitionActive() {
        return processDefinitionActive;
    }

    public void setProcessDefinitionActive(Boolean processDefinitionActive) {
        this.processDefinitionActive = processDefinitionActive;
    }

    public String getProcessDeployTime() {
        return processDeployTime;
    }

    public void setProcessDeployTime(String processDeployTime) {
        this.processDeployTime = processDeployTime;
    }

    public String getProcessDeployId() {
        return processDeployId;
    }

    public void setProcessDeployId(String processDeployId) {
        this.processDeployId = processDeployId;
    }
}
