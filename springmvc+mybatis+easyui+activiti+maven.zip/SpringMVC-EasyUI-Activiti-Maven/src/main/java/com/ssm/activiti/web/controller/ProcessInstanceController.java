package com.ssm.activiti.web.controller;

import com.ssm.activiti.web.service.WorkflowService;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ProcessEngine;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.impl.RepositoryServiceImpl;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.pvm.PvmTransition;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
import org.activiti.engine.repository.Model;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.runtime.ProcessInstanceQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2014-8-27.
 */
@Controller
@RequestMapping(value = "/workflow/processinstance")
public class ProcessInstanceController {
    @Autowired
    protected RuntimeService runtimeService;
    @Autowired
    private RepositoryService repositoryService;
    @Autowired
    private HistoryService historyService;
    @Autowired
    private WorkflowService workflowService;
    @Autowired
    private ProcessEngine processEngine;

    @RequestMapping(value = "running")
    public ModelAndView running(Model model, HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("/workflow/running-manage");

        ProcessInstanceQuery processInstanceQuery = runtimeService.createProcessInstanceQuery();
        List<ProcessInstance> list = processInstanceQuery.listPage(1, 10);
        return mav;
    }

    /**
     * 挂起、激活流程实例
     */
    @RequestMapping(value = "update/{state}/{processInstanceId}")
    public String updateState(@PathVariable("state") String state, @PathVariable("processInstanceId") String processInstanceId,
                              RedirectAttributes redirectAttributes) {
        if (state.equals("active")) {
            redirectAttributes.addFlashAttribute("message", "已激活ID为[" + processInstanceId + "]的流程实例。");
            runtimeService.activateProcessInstanceById(processInstanceId);
        } else if (state.equals("suspend")) {
            runtimeService.suspendProcessInstanceById(processInstanceId);
            redirectAttributes.addFlashAttribute("message", "已挂起ID为[" + processInstanceId + "]的流程实例。");
        }
        return "redirect:/workflow/processinstance/running";
    }

    /**
     * 显示流程图
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/workflow/imageResource")
    public ModelAndView getProcessPic(String processDefinitionId) throws Exception {
        //根据流程定义Id取得流程定义实体
        ProcessDefinition procDef = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();
        //获取图片资源
        String diagramResourceName = procDef.getDiagramResourceName();
        InputStream imageStream = repositoryService.getResourceAsStream(procDef.getDeploymentId(), diagramResourceName);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("inputStream", imageStream);
        modelAndView.setViewName("workflow/image-resource");
        return modelAndView;
    }

    /**
     * 获取跟踪信息
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/workflow/trace-process")
    public ModelAndView getProcessMap(String processDefinitionId, String processInstanceId) throws Exception {
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionId(processDefinitionId).singleResult();

        ProcessDefinitionImpl pdImpl = (ProcessDefinitionImpl) processDefinition;
        processDefinitionId = pdImpl.getId();
        ProcessDefinitionEntity def = (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(processDefinitionId);
        ActivityImpl actImpl = null;
        List<ActivityImpl> actImpls = new ArrayList<ActivityImpl>();
        //流程实例对象
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        //已经走过的所有节点
        List<HistoricActivityInstance> historicActivityInstances = workflowService.historicActivityInstances(processInstanceId);
        //查询执行实例
        //ExecutionEntity execution = (ExecutionEntity) runtimeService.createExecutionQuery().executionId(processInstanceId).singleResult();// 执行实例
        // 当前实例的执行到哪个节点
        List<String> activityIdList = new ArrayList<String>();
        //循环获得走过的activityId列表
        for (HistoricActivityInstance activityInstance : historicActivityInstances) {
            String activitiId = activityInstance.getActivityId();
            activityIdList.add(activitiId);
            ActivityImpl activityImpl = def.findActivity(activitiId);
            actImpls.add(activityImpl);
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("coordinateObj", actImpls);
        modelAndView.addObject("processDefinitionId", processDefinitionId);
        modelAndView.setViewName("workflow/trace");
        return modelAndView;
    }

    @RequestMapping(value = "/process/trace/auto/{executionId}/{processDefinitionId}")
    public void readResource(@PathVariable("executionId") String executionId, @PathVariable("processDefinitionId") String processDefinitionId, HttpServletResponse response)
            throws Exception {
        //查询运行时流程实例
        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(executionId).singleResult();
        /*ProcessInstance processInstance = null;
        processInstance = runtimeService.createProcessInstanceQuery().processInstanceId(executionId).singleResult();*/
        ProcessDefinitionEntity def = (ProcessDefinitionEntity) ((RepositoryServiceImpl) repositoryService).getDeployedProcessDefinition(processDefinitionId);

        if (historicProcessInstance == null) {
            throw new RuntimeException("获取流程图异常!");
        } else {
            BpmnModel bpmnModel = repositoryService.getBpmnModel(historicProcessInstance.getProcessDefinitionId());
            List<HistoricActivityInstance> activityInstances = historyService.createHistoricActivityInstanceQuery().processInstanceId(executionId).orderByHistoricActivityInstanceStartTime().asc().list();
            List<String> activitiIds = new ArrayList<String>();
            List<String> flowIds = new ArrayList<String>();
            flowIds = this.getHighLightedFlows(def, activityInstances);//获取流程走过的线
            for (HistoricActivityInstance historicActivityInstance : activityInstances) {
                activitiIds.add(historicActivityInstance.getActivityId());
            }
            if (historicProcessInstance.getEndTime() != null) {
                activitiIds.clear();
            } else {
                String currentActivityId = activitiIds.get(activitiIds.size() - 1);
                activitiIds.clear();
                activitiIds.add(currentActivityId);
            }
            InputStream imageStream = processEngine.getProcessEngineConfiguration().getProcessDiagramGenerator()
                    .generateDiagram(bpmnModel, "png", activitiIds, flowIds,
                            processEngine.getProcessEngineConfiguration().getActivityFontName(),
                            processEngine.getProcessEngineConfiguration().getLabelFontName(),
                            processEngine.getProcessEngineConfiguration().getClassLoader(), 1.0);
            // 输出资源内容到相应对象
            byte[] b = new byte[1024];
            int len;
            //FileUtils.copyInputStreamToFile(imageStream,new File("E:\\1.png"));
            response.setCharacterEncoding("utf-8");
            while ((len = imageStream.read(b, 0, 1024)) != -1) {
                response.getOutputStream().write(b, 0, len);
            }

        }
    }

    public List<String> getHighLightedFlows(ProcessDefinitionEntity processDefinitionEntity, List<HistoricActivityInstance> historicActivityInstances) {

        List<String> highFlows = new ArrayList<String>();// 用以保存高亮的线flowId  
        for (int i = 0; i < historicActivityInstances.size(); i++) {// 对历史流程节点进行遍历 
            ActivityImpl activityImpl = processDefinitionEntity.findActivity(historicActivityInstances.get(i).getActivityId());// 得到节点定义的详细信息    
            List<ActivityImpl> sameStartTimeNodes = new ArrayList<ActivityImpl>();// 用以保存后需开始时间相同的节点 
            if ((i + 1) >= historicActivityInstances.size()) {
                break;
            }
            ActivityImpl sameActivityImpl1 = processDefinitionEntity.findActivity(historicActivityInstances.get(i + 1).getActivityId());// 将后面第一个节点放在时间相同节点的集合里 
            sameStartTimeNodes.add(sameActivityImpl1);
            for (int j = i + 1; j < historicActivityInstances.size() - 1; j++) {
                HistoricActivityInstance activityImpl1 = historicActivityInstances.get(j);// 后续第一个节点 
                HistoricActivityInstance activityImpl2 = historicActivityInstances.get(j + 1);// 后续第二个节点 
                if (activityImpl1.getStartTime().equals(activityImpl2.getStartTime())) {// 如果第一个节点和第二个节点开始时间相同保存 
                    ActivityImpl sameActivityImpl2 = processDefinitionEntity.findActivity(activityImpl2.getActivityId());
                    sameStartTimeNodes.add(sameActivityImpl2);
                } else {// 有不相同跳出循环 
                    break;
                }
            }
            List<PvmTransition> pvmTransitions = activityImpl.getOutgoingTransitions();// 取出节点的所有出去的线    
            for (PvmTransition pvmTransition : pvmTransitions) {// 对所有的线进行遍历 
                ActivityImpl pvmActivityImpl = (ActivityImpl) pvmTransition.getDestination();// 如果取出的线的目标节点存在时间相同的节点里，保存该线的id，进行高亮显示 
                if
                        (sameStartTimeNodes.contains(pvmActivityImpl)) {
                    highFlows.add(pvmTransition.getId());
                }
            }
        }
        return highFlows;
    }

}
