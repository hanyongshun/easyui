package com.ssm.activiti.web.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.ssm.web.model.PageHelper;
import org.activiti.bpmn.converter.BpmnXMLConverter;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.editor.constants.ModelDataJsonConstants;
import org.activiti.editor.language.json.converter.BpmnJsonConverter;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.Model;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-25.
 */
@Controller
@RequestMapping("/workflow/model")
public class ModelController {
    protected Logger logger = LoggerFactory.getLogger(this.getClass());//日志属性

    @Autowired
    protected RepositoryService repositoryService;

    /**
     * 跳转到模型列表页面
     *
     * @return
     */
    @RequestMapping("list")
    public String showModelList() {
        return "model/modellist";
    }

    /**
     * 创建模型
     *
     * @return
     */
    @RequestMapping(value = "create", method = RequestMethod.POST)
    public void create(@RequestParam("key") String key, @RequestParam("name") String name, @RequestParam("description") String description, HttpServletRequest request, HttpServletResponse response) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode editorNode = objectMapper.createObjectNode();
            editorNode.put("id", "canvas");
            editorNode.put("resourceId", "canvas");
            ObjectNode stencilSetNode = objectMapper.createObjectNode();
            stencilSetNode.put("namespace", "http://b3mn.org/stencilset/bpmn2.0#");
            editorNode.put("stencilset", stencilSetNode);
            Model modelData = repositoryService.newModel();

            ObjectNode modelObjectNode = objectMapper.createObjectNode();
            modelObjectNode.put(ModelDataJsonConstants.MODEL_NAME, name);
            modelObjectNode.put(ModelDataJsonConstants.MODEL_REVISION, 1);
            description = StringUtils.defaultString(description);
            modelObjectNode.put(ModelDataJsonConstants.MODEL_DESCRIPTION, description);
            modelData.setMetaInfo(modelObjectNode.toString());
            modelData.setName(name);
            modelData.setKey(StringUtils.defaultString(key));

            repositoryService.saveModel(modelData);
            repositoryService.addModelEditorSource(modelData.getId(), editorNode.toString().getBytes("utf-8"));

            response.sendRedirect(request.getContextPath() + "/service/editor?id=" + modelData.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 模型列表
     *
     * @return
     */
    @RequestMapping(value = "jsonList")
    @ResponseBody
    public Map<String, Object> modelList(PageHelper pageHelper) {
        Map<String, Object> map = new HashMap<String, Object>();
        try {
            int pageSize = pageHelper.getRows();
            int pageNo = pageHelper.getPage() == 0 ? 1 : pageHelper.getPage();
            int startNo = (pageNo - 1) * pageSize;
            List<Model> modelList = repositoryService.createModelQuery().listPage(startNo, pageSize);
            int total = modelList == null ? 0 : modelList.size();
            map.put("total", total);
            map.put("rows", modelList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 编辑模型
     *
     * @param response
     */
    @RequestMapping("edit")
    public void edit(HttpServletResponse response, HttpServletRequest request, @RequestParam String ids) {
        String[] idsArray;
        try {
            idsArray = ids.split(",");
            for (String modelId : idsArray) {
                response.sendRedirect(request.getContextPath() + "/service/editor?id=" + modelId);
                logger.info("跳转模型编辑页面成功：modelId={}", modelId);
            }
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("跳转模型编辑页面失败:modelId={}", "", e);
        }
    }

    /**
     * 发布model
     *
     * @param ids
     * @return
     */
    @RequestMapping("deploy")
    @ResponseBody
    public Boolean deploy(@RequestParam String ids) {
        try {
            //处理ids
            String[] idsArray = ids.split(",");
            if (idsArray.length > 0) {
                for (String modelId : idsArray) {String a = "^[A-Z]{2}\\d{8}$";
                    //1、通过modelId获得model
                    Model modelData = repositoryService.getModel(modelId);
                    //2、转化model
                    ObjectMapper objectMapper = new ObjectMapper();
                    ObjectNode objectNode = (ObjectNode) objectMapper.readTree(repositoryService.getModelEditorSource(modelId));
                    //3、转化成bpmnmodel对象
                    byte[] bpmnBytes = null;
                    BpmnModel model = new BpmnJsonConverter().convertToBpmnModel(objectNode);
                    bpmnBytes = new BpmnXMLConverter().convertToXML(model, "utf-8");
                    //4、获取流程name
                    String processName = modelData.getName() + ".bpmn20.xml";
                    Deployment deployment = repositoryService.createDeployment().name(modelData.getName()).addString(processName, new String(bpmnBytes, "utf-8")).deploy();
                    logger.info("部署成功，部署ID=" + deployment.getId());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("根据模型部署流程失败：modelId={}", e);
            return false;
        }
        return true;
    }

    /**
     * 导出模型
     *
     * @param modelId
     * @param response
     */
    @RequestMapping("export")
    public void export(@RequestParam String modelId, HttpServletResponse response) {
        try {
            Model modelData = repositoryService.getModel(modelId);
            BpmnJsonConverter jsonConverter = new BpmnJsonConverter();
            JsonNode editorNode = new ObjectMapper().readTree(repositoryService.getModelEditorSource(modelData.getId()));
            BpmnModel bpmnModel = jsonConverter.convertToBpmnModel(editorNode);
            BpmnXMLConverter xmlConverter = new BpmnXMLConverter();
            byte[] bpmnBytes = xmlConverter.convertToXML(bpmnModel);

            ByteArrayInputStream in = new ByteArrayInputStream(bpmnBytes);
            IOUtils.copy(in, response.getOutputStream());
            String filename = bpmnModel.getMainProcess().getId() + ".bpmn20.xml";
            response.setHeader("Content-Disposition", "attachment; filename=" + filename);
            response.flushBuffer();
        } catch (Exception e) {
            logger.error("导出model的xml文件失败：modelId={}", modelId, e);
        }
    }

    /**
     * 删除
     *
     * @param ids
     * @return
     */
    @RequestMapping("delete")
    @ResponseBody
    public boolean delete(@RequestParam String ids) {
        boolean flag;
        try {
            String[] ids_arr = ids.split(",");
            for (int i = 0; i < ids_arr.length; i++) {
                String modelId = ids_arr[i];
                repositoryService.deleteModel(modelId);
            }
        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
            return flag;
        }
        flag = true;
        return flag;
    }
}
