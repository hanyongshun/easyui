package com.ssm.activiti.web.service;

import com.ssm.web.model.PageHelper;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;

import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-25.
 */
public interface WorkflowProcessDefinitionService {
    /**
     * 根据流程实例Id查询流程定义
     * @param processInstanceId
     * @return
     */
    public ProcessDefinition findProcessDefinitionByPiid(String processInstanceId);
    /**
     * 根据流程定义Id查询流程定义Id
     * @param processDefinitionId
     * @return
     */
    ProcessDefinition findProcessDefinitionByPdid(String processDefinitionId);

    /**
     * 流程定义列表
     * @param pageHelper
     * @return
     */
    Map<String, Object> findProcessDefinitionList(PageHelper pageHelper);

    /**
     * 启动流程by Key
     * @param applyUserId
     * @param processInstanceKey
     * @param businessKey
     * @param variables
     * @return
     */
    public ProcessInstance startByKey(String applyUserId, String processInstanceKey, String businessKey, Map<String, Object> variables);
}
