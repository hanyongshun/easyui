package com.ssm.web.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssm.web.model.User;
import com.ssm.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014/8/20.
 */
@Controller
@RequestMapping("/")
public class UserController {
    @Autowired
    private UserService userService;

    /**
     * 进入登录页面
     *
     * @return
     */
    @RequestMapping("/")
    public String index() {
        return "index";
    }

    /**
     * 主页
     *
     * @return
     */
    @RequestMapping("/main")
    public String main() {
        return "main";
    }

    /**
     * welcome
     *
     * @return
     */
    @RequestMapping("/welcome")
    public String welcome() {
        return "welcome";
    }

    /**
     * 登录操作
     *
     * @param user
     * @param session
     * @return
     */
    @RequestMapping("login")
    @ResponseBody
    public Map<String, Object> login(User user, HttpSession session) {
        boolean flag = false;//默认登录失败
        Map<String, Object> map = new HashMap<String, Object>();
        User userTemp = null;
        try {
            userTemp = userService.selectUserByUserIdAndPwd(user);
        } catch (Exception e) {
            e.printStackTrace();
            map.put("success", flag);
        }
        if (userTemp == null) {
            flag = false;
            map.put("success", flag);
            return map;
        }
        flag = true;
        map.put("success", flag);
        session.setAttribute("userId", userTemp.getUserId());//存储到session
        return map;
    }

    /**
     * 添加操作
     *
     * @param users
     * @return
     */
    @RequestMapping("user/add")
    @ResponseBody
    public boolean add(@RequestParam String users) {
        boolean flag;
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            User[] usersArr = objectMapper.readValue(users, User[].class);
            List<User> list = Arrays.asList(usersArr);
            if (list != null && list.size() > 0) {
                for (User user : list) {
                    if (user == null) {
                        continue;
                    }
                    if (user.getId() > 0) {
                        userService.updateUser(user);
                    }
                    userService.insertUser(user);
                }
            }
            flag = true;
        } catch (IOException e) {
            e.printStackTrace();
            flag = false;
        }
        return flag;
    }

    /**
     * 删除
     *
     * @param ids
     * @return
     */
    @RequestMapping("user/delete")
    @ResponseBody
    public boolean delete(String ids) {
        boolean flag;
        try {
            userService.delete(ids);
        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
        }
        flag = true;
        return flag;
    }

    /**
     * 用户列表
     *
     * @param page
     * @param rows
     * @return
     */
    @RequestMapping("user/list")
    @ResponseBody
    private Map<String, Object> findAll(@RequestParam int page, @RequestParam int rows, @RequestParam(value = "sort", required = false) String sortName, @RequestParam(value = "order", required = false) String sortOrder, User user) {
        List<User> userlist = userService.findAll(page, rows, sortName, sortOrder, user);
        int total = userService.countAll(user);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("total", total);
        map.put("rows", userlist);
        return map;
    }

    public String edit(User user) {
        return "";
    }

    /**
     * 显示用户列表页面
     *
     * @return
     */
    @RequestMapping("user/listPage")
    public String showUserList() {
        return "user-list-page";
    }
}
