package com.ssm.web.dao;

import com.ssm.web.model.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by shizhenchao on 2014/8/20.
 */
public interface UserDao {

    /**
     * 添加新用户
     *
     * @param user
     * @return
     */
    public int insertUser(User user);

    /**
     * 通过用户名密码查询用户
     *
     * @param user
     */
    User findUserByUserIdAndPwd(User user);

    public List<User> findAll(@Param("pageNo") int pageNo, @Param("pageSize") int pageSize, @Param("sortName") String sortName, @Param("sortOrder") String sortOrder, @Param("user") User user);

    int countAll(@Param("user") User user);

    void delete(@Param("ids") String ids);

    void update(User user);
}
