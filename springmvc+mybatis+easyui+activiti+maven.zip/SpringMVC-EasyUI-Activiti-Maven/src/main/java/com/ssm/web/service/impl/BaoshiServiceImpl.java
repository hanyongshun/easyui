package com.ssm.web.service.impl;

import com.ssm.activiti.web.service.WorkflowService;
import com.ssm.web.dao.BaoshiDao;
import com.ssm.web.model.Baoshi;
import com.ssm.web.model.PageHelper;
import com.ssm.web.service.BaoshiService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-28.
 */
@Service
public class BaoshiServiceImpl implements BaoshiService {

    @Autowired
    protected WorkflowService workflowService;
    @Autowired
    protected HistoryService historyService;

    @Autowired
    protected BaoshiDao baoshiDao;

    @Override
    public boolean save(Baoshi baoshi, HttpSession session) throws Exception {
        try {
            //保存报事信息
            baoshiDao.save(baoshi);
            //获得报事信息id
            String businessKey = baoshi.getId() + "";
            String userId = (String) session.getAttribute("userId");
            ProcessInstance processInstance = workflowService.startByKey(userId, "BsProcess", businessKey, new HashMap<String, Object>());
            int id = baoshi.getId();
            //通过id查询并且赋值流程实例Id字段
            baoshi.setProcessInstanceId(processInstance.getId());
            baoshi.setId(id);
            baoshiDao.update(baoshi);
            //启动工作流
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 查询待办报事
     *
     * @param session
     * @param pageHelper
     * @return
     */
    @Override
    public Map<String, Object> searchUndoTask(HttpSession session, PageHelper pageHelper) {
        int pageSize = pageHelper.getRows();
        int pageNo = pageHelper.getPage() == 0 ? 1 : pageHelper.getPage();
        int startNo = (pageNo - 1) * pageSize;
        Map<String, Object> map = new HashMap<String, Object>();
        List<Task> taskList = workflowService.showUndoTaskList(session, startNo, pageSize);
        List<Map<String, Object>> maps = new ArrayList<Map<String, Object>>();
        for (Task task : taskList) {
            Map<String, Object> map1 = new HashMap<String, Object>();
            map1.put("name", task.getName());
            map1.put("id", task.getId());
            map1.put("executionId", task.getExecutionId());
            map1.put("processInstanceId", task.getProcessInstanceId());
            map1.put("processDefinitionId", task.getProcessDefinitionId());
            map1.put("createTime", task.getCreateTime());
            map1.put("assignee", task.getAssignee());
            //查询流程实例Id
            String processInstanceId = task.getProcessInstanceId();
            //查询流程实例
            ProcessInstance processInstance = workflowService.searchProcessInstanceById(processInstanceId);
            String businessKey = processInstance.getBusinessKey();
            if (businessKey == null) {
                continue;
            }
            Baoshi baoshi = baoshiDao.selectById(Integer.valueOf(businessKey));
            map1.put("baoshi", baoshi);
            maps.add(map1);
        }
        map.put("rows", maps);
        int total = Integer.parseInt(workflowService.countUndoTaskList(session) + "");
        map.put("total", total);
        return map;
    }

    /**
     * 签收
     *
     * @param session
     * @param taskId
     */
    @Override
    public void claim(HttpSession session, String taskId) {
        workflowService.claim(taskId, (String) session.getAttribute("userId"));
    }

    /**
     * 查询我派发的工单
     *
     * @param session
     * @return
     */
    @Override
    public Map<String, Object> historyTasksStartByMe(HttpSession session) {
        Map<String, Object> map = new HashMap<String, Object>();
        List<HistoricProcessInstance> historicProcessInstances = workflowService.finishedHistoricProcessInstances((String) session.getAttribute("userId"));
        map.put("rows", historicProcessInstances);
        return map;
    }

    /**
     * 显示详细信息
     *
     * @param taskId
     */
    @Override
    public Map<String, Object> shwoDetail(String taskId) {
        Task task = workflowService.searchTaskByTaskId(taskId);
        //查询流程实例Id
        String processInstanceId = task.getProcessInstanceId();
        //查询流程实例
        ProcessInstance processInstance = workflowService.searchProcessInstanceById(processInstanceId);
        String businessKey = processInstance.getBusinessKey();
        Baoshi baoshi = baoshiDao.selectById(Integer.valueOf(businessKey));
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("task", task);
        map.put("businessBean", baoshi);
        return map;
    }

    @Override
    public List<HistoricActivityInstance> historicActivityInstances(String processInstanceId) {
        return workflowService.historicActivityInstances(processInstanceId);
    }

    public void refer(String taskId, Map<String, Object> varables) {
        workflowService.referTask(taskId, varables);
    }

    public Map<String, Object> historyInvolvedUser(HttpSession session, PageHelper pageHelper) {
        int startNo = (pageHelper.getPage() - 1) * pageHelper.getRows();
        String userId = (String) session.getAttribute("userId");
        return workflowService.historyInvolvedUser(userId, startNo, pageHelper.getRows());
    }

    /**
     * 历史详细信息
     *
     * @param processInstanceId
     * @return
     */
    public Map<String, Object> shwoHistoryDetail(String processInstanceId) {
        HistoricProcessInstance historicProcessInstances = workflowService.searchHistoryProcessInstanceById(processInstanceId);
        String businessKey = historicProcessInstances.getBusinessKey();
        Baoshi baoshi = baoshiDao.selectById(Integer.valueOf(businessKey));
        Map<String, Object> map = new HashMap<String, Object>();
        //map.put("task", task);
        map.put("businessBean", baoshi);
        return map;
    }

}
