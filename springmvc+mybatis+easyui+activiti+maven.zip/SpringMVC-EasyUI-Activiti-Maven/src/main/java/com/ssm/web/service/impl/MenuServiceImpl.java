package com.ssm.web.service.impl;

import com.ssm.web.dao.MenuDao;
import com.ssm.web.model.EasyUITree;
import com.ssm.web.model.TreeDTO;
import com.ssm.web.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by shizhenchao on 2014-9-2.
 */
@Service
public class MenuServiceImpl implements MenuService {
    @Autowired
    protected MenuDao menuDao;

    /**
     * 查询系统菜单
     *
     * @param id
     * @return
     */
    @Override
    public List<TreeDTO> ctrlTree(Integer id) {
        return menuDao.ctrlTree(id);
    }

    @Override
    public int countChildrens(String id) {
        return menuDao.countChildrens(id);
    }
}
