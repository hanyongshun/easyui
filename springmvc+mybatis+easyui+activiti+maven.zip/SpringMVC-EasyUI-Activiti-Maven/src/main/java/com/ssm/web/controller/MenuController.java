package com.ssm.web.controller;

import com.ssm.web.model.EasyUITree;
import com.ssm.web.model.TreeDTO;
import com.ssm.web.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-21.
 */
@Controller
public class MenuController {
    @Autowired
    protected MenuService menuService;

    @RequestMapping("ctrlTree")
    @ResponseBody
    public List<EasyUITree> ctrlTree(@RequestParam(required = false) Integer id) {
        List<TreeDTO> list = menuService.ctrlTree(id);
        List<EasyUITree> uiTrees = new ArrayList<EasyUITree>();
        if (list.size() != 0) {
            for (TreeDTO t : list) {
                EasyUITree e = new EasyUITree();
                e.setId(t.getId());
                e.setText(t.getText());
                e.setIconCls(t.getIconCls());
                Map<String, Object> attributes = new HashMap<String, Object>();
                attributes.put("url", t.getUrl());
                e.setAttributes(attributes);
                int count = menuService.countChildrens(t.getId());
                if (count > 0) {
                    //注意state这个属性、当他为open时、说明这个节点是个文件夹、会以文件夹的形式显示、
                    // 当他是closed的时候、说明这个节点是一个具体的文件节点、不会以文件夹的形式显示。
                    e.setState("closed");
                }
                uiTrees.add(e);
            }
        }
        //id = null;
        //将含有用于显示tree的信息的集合、转换成json格式、传到前台。
        return uiTrees;
    }
}