package com.ssm.web.service.impl;

import com.ssm.web.dao.UserDao;
import com.ssm.web.model.User;
import com.ssm.web.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by shizhenchao on 2014/8/20.
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;

    @Override
    public int insertUser(User user) {
        return userDao.insertUser(user);
    }

    /**
     * 通过用户名密码查询用户
     *
     * @param user
     * @return
     */
    @Override
    public User selectUserByUserIdAndPwd(User user) {
        return userDao.findUserByUserIdAndPwd(user);
    }

    @Override
    public List<User> findAll(int pageNo, int pageSize, String sortName, String sortOrder, User user) {
        int start = (pageNo - 1) * pageSize;
        return userDao.findAll(start, pageSize, sortName, sortOrder, user);
    }

    /**
     * 查询全部记录数
     *
     * @return
     */
    @Override
    public int countAll(User user) {
        return userDao.countAll(user);
    }

    @Override
    public void delete(String ids) {
        userDao.delete(ids);
    }

    public void updateUser(User user) {
        userDao.update(user);
    }
}
