package com.ssm.web.controller;

import com.ssm.web.model.Baoshi;
import com.ssm.web.model.PageHelper;
import com.ssm.web.service.BaoshiService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-27.
 */
@Controller
@RequestMapping("/baoshi")
public class BaoshiController {
    @Autowired
    protected BaoshiService baoshiService;

    @RequestMapping("main")
    public ModelAndView baoshi_mainPage() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("commonform/baoshi/baoshi");
        return modelAndView;
    }

    @RequestMapping("newform")
    public ModelAndView newForm() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("commonform/baoshi/newform");
        return modelAndView;
    }

    @RequestMapping("dealNewForm")
    @ResponseBody
    public boolean dealNewForm(Baoshi baoshi, HttpSession session) {
        boolean flag = false;//默认保存失败
        try {
            flag = baoshiService.save(baoshi, session);
        } catch (Exception e) {
            e.printStackTrace();
            return flag;
        }
        return flag;
    }

    /**
     * 跳转到待办任务页面
     *
     * @return
     */
    @RequestMapping("undoTaskList")
    public String undoTaskList() {
        return "commonform/baoshi/undotask";
    }

    /**
     * 查询待办任务数据
     *
     * @param session
     * @param pageHelper
     * @return
     */
    @RequestMapping("undoTaskListData")
    @ResponseBody()
    public Map<String, Object> baoshiUndoTask(HttpSession session, PageHelper pageHelper) {
        Map<String, Object> map = null;
        map = baoshiService.searchUndoTask(session, pageHelper);
        return map;
    }

    @RequestMapping("claim")
    @ResponseBody
    public boolean claim(String taskId, HttpSession session) {
        boolean flag;//开关
        try {
            baoshiService.claim(session, taskId);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
            flag = false;
            return flag;
        }
        return flag;
    }

    @RequestMapping("history-owner-task")
    public String historyStartBySelfTasks() {
        return "commonform/baoshi/history-owner-task";
    }

    @RequestMapping("history-startBySelf-tasks")
    @ResponseBody
    public Map<String, Object> historyTask(HttpSession session) {
        Map<String, Object> map;
        map = baoshiService.historyTasksStartByMe(session);
        return map;
    }

    @RequestMapping("historyOwnerTask")
    public String historyTaskPage() {
        return "history-owner-task";
    }

    /**
     * 详细信息总页面
     */
    @RequestMapping("ownerHistoryDetailPage")
    public ModelAndView ownerHistoryDetail(String id, String processDefinitionId, String processInstanceId) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("id", id);
        modelAndView.addObject("processDefinitionId", processDefinitionId);
        modelAndView.addObject("processInstanceId", processInstanceId);
        modelAndView.setViewName("commonform/baoshi/history-owner-detail");
        return modelAndView;
    }

    /**
     * 报事详细信息
     *
     * @param taskId
     * @return
     */
    @RequestMapping("detail")
    public ModelAndView detail(String taskId) {
        //根据taskId查询task记录
        Map<String, Object> map = baoshiService.shwoDetail(taskId);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("task", map.get("task"));
        modelAndView.addObject("businessBean", map.get("businessBean"));
        modelAndView.setViewName("commonform/baoshi/detail");
        return modelAndView;
    }

    /**
     * 报事详细信息
     *
     * @param processInstanceId
     * @return
     */
    @RequestMapping("historyDetail")
    public ModelAndView historyDetail(String processInstanceId) {
        //根据taskId查询task记录
        Map<String, Object> map = baoshiService.shwoHistoryDetail(processInstanceId);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("task", map.get("task"));
        modelAndView.addObject("businessBean", map.get("businessBean"));
        modelAndView.setViewName("commonform/baoshi/detail");
        return modelAndView;
    }

    @RequestMapping("transferInfo")
    public ModelAndView transferInfo(String processInstanceId) {
        ModelAndView modelAndView = new ModelAndView();
        List<HistoricActivityInstance> historicActivityInstances = baoshiService.historicActivityInstances(processInstanceId);
        modelAndView.addObject("historicActivityInstances", historicActivityInstances);
        modelAndView.setViewName("commonform/baoshi/transfer");
        return modelAndView;
    }

    @RequestMapping("deal-form-page")
    public ModelAndView deal(String taskId) {
        ModelAndView modelAndView = new ModelAndView();
        Map<String, Object> map = baoshiService.shwoDetail(taskId);
        modelAndView.addObject("task", map.get("task"));
        modelAndView.addObject("businessBean", map.get("businessBean"));
        modelAndView.setViewName("commonform/baoshi/deal-form-page");
        return modelAndView;
    }

    @RequestMapping("refer")
    @ResponseBody
    public boolean refer(String taskId, Baoshi baoshi) {
        Map<String, Object> varables = new HashMap<String, Object>();
        try {
            varables.put("type", baoshi.getType());
            baoshiService.refer(taskId, varables);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * 加载我参与处理的工单列表数据
     *
     * @param session
     * @param pageHelper
     * @return
     */
    @RequestMapping("historyInvolvedUser")
    @ResponseBody
    public Map<String, Object> historyInvolvedUser(HttpSession session, PageHelper pageHelper) {
        Map<String, Object> map = baoshiService.historyInvolvedUser(session, pageHelper);
        return map;
    }

    @RequestMapping("history-involved-page")
    public String historyInvolvedPage() {
        return "commonform/baoshi/history-involved-page";
    }

}
