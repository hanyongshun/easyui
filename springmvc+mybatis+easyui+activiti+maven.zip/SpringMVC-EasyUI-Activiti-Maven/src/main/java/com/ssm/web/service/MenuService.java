package com.ssm.web.service;

import com.ssm.web.model.TreeDTO;

import java.util.List;

/**
 * Created by shizhenchao on 2014-9-2.
 */
public interface MenuService {
    /**
     * 查询系统菜单
     *
     * @param id
     * @return
     */
    List<TreeDTO> ctrlTree(Integer id);

    int countChildrens(String id);
}
