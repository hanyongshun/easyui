package com.ssm.web.dao;

import com.ssm.web.model.Baoshi;
import org.springframework.stereotype.Repository;

/**
 * Created by shizhenchao on 2014-8-28.
 */
@Repository
public interface BaoshiDao {
    int save(Baoshi baoshi);

    /**
     * 通过id查询
     * @param id
     * @return
     */
    Baoshi selectById(int id);

    void update(Baoshi user);
}
