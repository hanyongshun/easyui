package com.ssm.web.dao;

import com.ssm.web.model.TreeDTO;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by shizhenchao on 2014-9-2.
 */
public interface MenuDao {
    /**
     * 查询菜单
     * @param id
     * @return
     */
    List<TreeDTO> ctrlTree(@Param("id") Integer id);

    int countChildrens(@Param("id") String id);
}
