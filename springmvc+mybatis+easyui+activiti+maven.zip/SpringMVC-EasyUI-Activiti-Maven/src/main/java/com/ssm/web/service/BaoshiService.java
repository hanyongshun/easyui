package com.ssm.web.service;

import com.ssm.web.model.Baoshi;
import com.ssm.web.model.PageHelper;
import org.activiti.engine.history.HistoricActivityInstance;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * Created by shizhenchao on 2014-8-28.
 */
public interface BaoshiService {
    boolean save(Baoshi baoshi, HttpSession session) throws Exception;

    /**
     * 查询待办报事
     * @param session
     * @param pageHelper
     * @return
     */
    Map<String,Object> searchUndoTask(HttpSession session, PageHelper pageHelper);

    /**
     * 签收
     * @param session
     * @param taskId
     */
    void claim(HttpSession session, String taskId);

    Map<String,Object> historyTasksStartByMe(HttpSession session);

    Map<String,Object> shwoDetail(String taskId);

    List<HistoricActivityInstance> historicActivityInstances(String processInstanceId);

    void refer(String taskId, Map<String, Object> varables);

    Map<String,Object> historyInvolvedUser(HttpSession session, PageHelper pageHelper);

    Map<String,Object> shwoHistoryDetail(String processInstanceId);
}
