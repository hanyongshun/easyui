package com.ssm.web.service;

import com.ssm.web.model.User;

import java.util.List;

/**
 * Created by shizhenchao on 2014/8/20.
 */
public interface UserService {
    /**
     * 添加用户
     * @param user
     * @return
     */
    public int insertUser(User user);

    /**
     * 通过用户名密码查询用户
     * @param user
     * @return
     */
    public User selectUserByUserIdAndPwd(User user);

    List<User> findAll(int pageNo, int pageSize, String sortName, String sortOrder, User user);

    /**
     * 查询全部记录数
     * @return
     */
    int countAll(User user);

    void delete(String ids);

    void updateUser(User user);
}
